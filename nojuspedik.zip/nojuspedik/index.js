console.log("nojus pedik");

const logger = require('./logger');
logger.log('pedikas');