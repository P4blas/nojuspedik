exports.log = function log(message) {
    console.log('NOJUS ' + message);
}